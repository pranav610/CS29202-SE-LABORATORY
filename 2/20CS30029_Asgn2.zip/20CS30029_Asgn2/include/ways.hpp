using namespace std;

// a class to store various attributes of ways
class ways
{
public:
    string name;
    ll id;
    vector<nodes> wayPoints; // to store list of ways on the node
};

