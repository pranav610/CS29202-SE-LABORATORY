from turtle import setup
import setuptools

setuptools.setup(name="my_package-pranav",
                version="0.0.1", author="Pranav Kulkarni",
                description="Software Assignment-3",
                packages=setuptools.find_packages()
                )