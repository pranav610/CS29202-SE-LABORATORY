# GUI FILE IMPORT
from UI_MainScreen import Ui_MainWindow

# IMPORT QSS CUSTOM FILE
from UI_Styles import Style

# IMPORT FUNCTIONS FOR GUI
from UI_Functions import *