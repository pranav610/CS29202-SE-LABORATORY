using namespace std;

void storeInput(unordered_map<ll, nodes> &nodesList, vector<ways> &waysList); // will store list of nodes in nodesList and list of ways in waysList
void searchInput(unordered_map<ll, nodes> &nodesList, string input); // search using matching substrings